package p1eva1rodriguezbrigitte;

import java.util.Scanner;

public class Camioneta {

    Scanner scanner = new Scanner(System.in);
    private int verde, maracuya;

    public Camioneta(int verde, int maracuya) {
        this.verde = verde;
        this.maracuya = maracuya;
    }
    //Getter y Setter

    public void setVerde() {
        this.verde = verde;
    }

    public void setMaracuya() {
        this.maracuya = maracuya;
    }

    public int getVerde(int verde) {
        return getverde;
    }

    public int getMaracuya(int maracuya) {
        return getmaracuya;
    }

    public void ingresoDatos() {
        boolean entradaDatos = false;
        while (!entradaDatos) {
            try {
                System.out.println("Cuantos verdes desea llevar en su camioneta: ");
                setVerde.nextInt();
                while (getVerde() < 1 || getVerde() > 10) {
                    System.out.println("El rango de verdes es 1-10: ");
                    setVerde.nextInt();
                }
                System.out.println("Cuantos sacos de maracuya desea llevar en la camioneta: ");
                setmaracuya.nextInt();
                while (getmaracuya() < 1 || getmaracuya() > 10) {
                    System.out.println("Ingrese en el rango devsacos es 1-10, intente nuevamente: ");
                    setmaracuya.nextInt();
                }
                entradaDatos = true;
            }
        }catch (Exception e){
             System.out.println("Los datos deben ser mayores de 0");
         }
