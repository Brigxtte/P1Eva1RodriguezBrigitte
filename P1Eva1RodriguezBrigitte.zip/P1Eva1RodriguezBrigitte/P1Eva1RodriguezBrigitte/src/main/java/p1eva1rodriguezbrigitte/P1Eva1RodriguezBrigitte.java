package p1eva1rodriguezbrigitte;

import java.util.Scanner;

public class P1Eva1RodriguezBrigitte {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Camioneta camioneta = newCamioneta(verde, maracuya);
        Barco barco = newBarco(anio, embarcaciones);

        camioneta.ingresoDatos();
        barco.ingresoDatosB();
    }
}
