package p1eva1rodriguezbrigitte;

import java.util.Scanner;

public class Barco {

    Scanner scanner = new Scanner(System.in);
    private int anio, embarcaciones;

    public Barco(int anio, int embarcaciones) {
        this.anio = anio;
        this.embarcaciones = embarcaciones;
    }
    //Getter y Setter

    public int getAnio(int anio) {
        return anio;
    }

    public void setAnio() {
        this.anio = anio;
    }

    public int getEmbarcaciones(int embarcaciones) {
        return embarcaciones;
    }

    public void setEmbarcaciones() {
        this.embarcaciones = embarcaciones;
    }

    public void ingresoDatosB() {
        boolean entradaDatosB = false;
        while (!entradaDatosB) {
            try {
                System.out.println("De que año es su barco: ");
                setAnio.nextInt();
                while (getAnio() < 2004 || getAnio() > 2024) {
                    System.out.println("Ingrese en el rango establecido, intente nuevamente: ");
                    setAnio.nextInt();
                    System.out.println("Cuantas embarcaciones tiene su barco: ");
                    setEmbarcaciones.nextInt();
                    while (getEmbarcaciones() < 1 || getEmbarcaciones() > 10) {
                        System.out.println("Ingrese en el rango, intente nuevamente: ");
                        setEmbarcaciones.nextInt();
                    }
                    entradaDatosB = true;
                }
            } catch (Exception e) {
                System.out.println("Los datos deben ser mayores de cero");
            }



}
