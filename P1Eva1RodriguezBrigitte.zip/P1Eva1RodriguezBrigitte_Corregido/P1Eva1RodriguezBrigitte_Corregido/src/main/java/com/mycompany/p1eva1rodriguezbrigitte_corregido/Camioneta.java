package com.mycompany.p1eva1rodriguezbrigitte_corregido;

import java.util.Scanner;

public class Camioneta {

    private Scanner scanner;
    private int verde, maracuya;

    // Constructor que solo recibe el scanner
    public Camioneta(Scanner scanner) {
        this.scanner = scanner;
    }

    // Getter y Setter
    public void setVerde(int verde) {
        this.verde = verde;
    }

    public int getVerde() {
        return verde;
    }

    public void setMaracuya(int maracuya) {
        this.maracuya = maracuya;
    }

    public int getMaracuya() {
        return maracuya;
    }

    // Ingreso de datos
    public void ingresoDatos() {
        boolean entradaDatos = false;

        while (!entradaDatos) {
            try {
                System.out.println("¿Cuantos verdes desea llevar en su camioneta? (1-10): ");
                int verdesInput = scanner.nextInt();
                while (verdesInput < 1 || verdesInput > 10) {
                    System.out.println("El rango de verdes es 1-10. Intente nuevamente.");
                    verdesInput = scanner.nextInt();
                }
                setVerde(verdesInput);

                System.out.println("¿Cuantos sacos de maracuya desea llevar en la camioneta? (1-10): ");
                int maracuyaInput = scanner.nextInt();
                while (maracuyaInput < 1 || maracuyaInput > 10) {
                    System.out.println("El rango de maracuyas es 1-10. Intente nuevamente.");
                    maracuyaInput = scanner.nextInt();
                }
                setMaracuya(maracuyaInput);

                entradaDatos = true;

            } catch (Exception e) {
                System.out.println("Entrada invalida. Asegurese de ingresar un numero valido.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }
}
