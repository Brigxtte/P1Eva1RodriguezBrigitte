package com.mycompany.p1eva1rodriguezbrigitte_corregido;

import java.util.Scanner;

public class Barco {

    private Scanner scanner;
    private int anio, embarcaciones;

    // Constructor que solo recibe el scanner
    public Barco(Scanner scanner) {
        this.scanner = scanner;
    }

    // Getter y Setter
    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getEmbarcaciones() {
        return embarcaciones;
    }

    public void setEmbarcaciones(int embarcaciones) {
        this.embarcaciones = embarcaciones;
    }

    // Ingreso de datos para el barco
    public void ingresoDatosB() {
        boolean entradaDatosB = false;
        while (!entradaDatosB) {
            try {
                // Solicitar el año del barco
                System.out.println("¿De que anio es su barco?");
                int anioInput = scanner.nextInt();
                while (anioInput < 2004 || anioInput > 2024) {
                    System.out.println("Ingrese un anio en el rango 2004-2024, intente nuevamente: ");
                    anioInput = scanner.nextInt();
                }
                setAnio(anioInput);

                // Solicitar el número de embarcaciones
                System.out.println("¿Cuantas embarcaciones tiene su barco?");
                int embarcacionesInput = scanner.nextInt();
                while (embarcacionesInput < 1 || embarcacionesInput > 10) {
                    System.out.println("Ingrese un numero de embarcaciones en el rango 1-10, intente nuevamente: ");
                    embarcacionesInput = scanner.nextInt();
                }
                setEmbarcaciones(embarcacionesInput);
                entradaDatosB = true;
            } catch (Exception e) {
                System.out.println("Los datos deben ser numeros válidos.");
                scanner.nextLine(); // Limpiar el buffer del scanner
            }
        }
    }
}
