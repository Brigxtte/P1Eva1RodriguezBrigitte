package com.mycompany.p1eva1rodriguezbrigitte_corregido;

import java.util.Scanner;

public class P1Eva1RodriguezBrigitte_Corregido {

    public static void main(String[] args) {

        // Crear el objeto scanner para entrada de datos
        Scanner scanner = new Scanner(System.in);

        // Crear una instancia para la camioneta
        Camioneta camioneta = new Camioneta(scanner);

        // Llamar al método de ingreso de datos de la camioneta
        camioneta.ingresoDatos();

        // Crear una instancia para el barco
        Barco barco = new Barco(scanner);

        // Llamar al método de ingreso de datos del barco
        barco.ingresoDatosB();

        // Mostrar los datos ingresados
        System.out.println("\nDatos Ingresados:");
        System.out.println("Su camioneta se encuentra cargada de:");
        System.out.println("Cantidad de verdes: " + camioneta.getVerde());
        System.out.println("Cantidad de maracuya: " + camioneta.getMaracuya());

        System.out.println("Su barco:");
        System.out.println("Anio del barco: " + barco.getAnio());
        System.out.println("Numero de embarcaciones: " + barco.getEmbarcaciones());

        // Cerrar el scanner
        scanner.close();
    }
}
